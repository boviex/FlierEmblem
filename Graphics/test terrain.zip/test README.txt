terrain.party README
====================

Hooray! You've exported some stuff from terrain.party v1.2!

If you should want to export this again for any reason:
  http://terrain.party/api/export?name=test&box=10.219753,51.616098,9.959342,51.454402

Now: what did you get?


Height Maps
-----------

No height map data was available. That's a bummer.

If you're way at the poles, that's probably why. Orbital measurements only go
so far away from the equator.

If this area is filled with water, try a box that has less water. That's
probably a good idea for gameplay reasons anyway.

Otherwise, this could be a problem with terrain.party. Retrying the link above
at a later time might help, or try posting it in the Discuss link for help.

At any rate: there's no height maps here. Sorry!

